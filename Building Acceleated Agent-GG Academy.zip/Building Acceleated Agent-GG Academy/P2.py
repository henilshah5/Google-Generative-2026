# Before: pandas (CPU) — ~4.2 min over 3 years × 5 locations of daily data
# import pandas as pd

# After: GPU-accelerated, same code
import cudf.pandas
cudf.pandas.install()
import pandas as pd

df = pd.read_gbq("SELECT * FROM finance.curated_daily_ledger", project_id="danielsbakery")

df = df.sort_values(["location_id", "ledger_date"])
df["dow"] = df["ledger_date"].dt.dayofweek
df["sales_7d_avg"] = df.groupby("location_id")["daily_sales"].transform(
    lambda s: s.rolling(7, min_periods=1).mean())
df["sales_28d_std"] = df.groupby("location_id")["daily_sales"].transform(
    lambda s: s.rolling(28, min_periods=1).std())
df["net_daily_flow"] = (df["daily_sales"] - df["payroll_outflow"]
                         - df["supplier_outflow"] - df["rent_outflow"])

df.to_parquet("gs://danielsbakery-features/daily_features.parquet")
