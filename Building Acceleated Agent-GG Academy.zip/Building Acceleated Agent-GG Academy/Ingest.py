-- BigQuery: unify daily POS + bank + invoice data per location
CREATE OR REPLACE TABLE finance.curated_daily_ledger AS
SELECT
  location_id, ledger_date,
  SUM(CASE WHEN txn_type = 'sale' THEN amount ELSE 0 END) AS daily_sales,
  SUM(CASE WHEN txn_type = 'payroll' THEN amount ELSE 0 END) AS payroll_outflow,
  SUM(CASE WHEN txn_type = 'supplier_invoice' THEN amount ELSE 0 END) AS supplier_outflow,
  SUM(CASE WHEN txn_type = 'rent' THEN amount ELSE 0 END) AS rent_outflow
FROM `raw.transactions`
WHERE ledger_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 3 YEAR)
GROUP BY location_id, ledger_date;