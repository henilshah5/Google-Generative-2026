from cuml.ensemble import RandomForestRegressor
import pandas as pd  # cudf.pandas already installed above

df = pd.read_parquet("gs://danielsbakery-features/daily_features.parquet")

features = ["dow", "sales_7d_avg", "sales_28d_std", "location_id"]
target = "net_daily_flow"

model = RandomForestRegressor(n_estimators=300, max_depth=10)
model.fit(df[features], df[target])

future_days = build_future_calendar(horizon_days=30)  # known payroll/rent/invoice dates
future_days["predicted_net_flow"] = model.predict(future_days[features])
future_days["projected_balance"] = (
    current_bank_balance + future_days.groupby("location_id")["predicted_net_flow"].cumsum()
)
future_days["shortfall_flag"] = future_days["projected_balance"] < 0

future_days.to_gbq("finance.cash_forecast_daily", if_exists="replace")